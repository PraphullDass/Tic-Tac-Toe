package application;

import java.util.ArrayList;
import java.util.Hashtable;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;


public class Main extends Application
{
	private Stage stage;
	private AnchorPane root;
	private String user = "O";
	private String computer = "X";
	private ArrayList<ArrayList<Integer>> wincombos;
	private ArrayList<Button> cells;
	private Hashtable<Integer, String> board;
	private Button exit;
	private Button replay;
	private Label message;
	
	private void initialise()
	{
		wincombos = new ArrayList<ArrayList<Integer>>();
		cells = new ArrayList<Button>();
		
		ArrayList<Integer> a = new ArrayList<Integer>();
		a.add(0);
		a.add(1);
		a.add(2);
		wincombos.add(a);
		
		a = new ArrayList<Integer>();
		a.add(3);
		a.add(4);
		a.add(5);
		wincombos.add(a);
		
		a = new ArrayList<Integer>();
		a.add(6);
		a.add(7);
		a.add(8);
		wincombos.add(a);
		
		a = new ArrayList<Integer>();
		a.add(0);
		a.add(3);
		a.add(6);
		wincombos.add(a);
		
		a = new ArrayList<Integer>();
		a.add(1);
		a.add(4);
		a.add(7);
		wincombos.add(a);

		a = new ArrayList<Integer>();
		a.add(2);
		a.add(5);
		a.add(8);
		wincombos.add(a);
		
		a = new ArrayList<Integer>();
		a.add(0);
		a.add(4);
		a.add(8);
		wincombos.add(a);
		
		a = new ArrayList<Integer>();
		a.add(2);
		a.add(4);
		a.add(6);
		wincombos.add(a);
		
		VBox vboard = new VBox();
		vboard.setLayoutX(140);
		vboard.setLayoutY(140);
		vboard.setSpacing(10);
		HBox row0 = new HBox();
		row0.setSpacing(10);
		HBox row1 = new HBox();
		row1.setSpacing(10);
		HBox row2 = new HBox();
		row2.setSpacing(10);

		Button cell0 = new Button();
		cell0.setId("cell0");
		Button cell1 = new Button();
		cell1.setId("cell1");
		Button cell2 = new Button();
		cell2.setId("cell2");
		Button cell3 = new Button();
		cell3.setId("cell3");
		Button cell4 = new Button();
		cell4.setId("cell4");
		Button cell5 = new Button();
		cell5.setId("cell5");
		Button cell6 = new Button();
		cell6.setId("cell6");
		Button cell7 = new Button();
		cell7.setId("cell7");
		Button cell8 = new Button();
		cell8.setId("cell8");
		
		cells.add(cell0);
		cells.add(cell1);
		cells.add(cell2);
		cells.add(cell3);
		cells.add(cell4);
		cells.add(cell5);
		cells.add(cell6);
		cells.add(cell7);
		cells.add(cell8);
		
		row0.getChildren().add(cell0);
		row0.getChildren().add(cell1);
		row0.getChildren().add(cell2);
		
		row1.getChildren().add(cell3);
		row1.getChildren().add(cell4);
		row1.getChildren().add(cell5);
		
		row2.getChildren().add(cell6);
		row2.getChildren().add(cell7);
		row2.getChildren().add(cell8);

		vboard.getChildren().add(row0);
		vboard.getChildren().add(row1);
		vboard.getChildren().add(row2);
		
		Label name = new Label("Tic-Tac-Toe");
		name.setPrefSize(300, 100);
		name.setLayoutX(150);
		name.setLayoutY(10);
		name.setFont(Font.font("viner hand itc", 50));
		name.setAlignment(Pos.CENTER);
		name.setTextFill(Color.WHITE);
		
		message = new Label("You Lose");
		message.setPrefSize(600, 100);
		message.setLayoutX(0);
		message.setLayoutY(450);
		message.setFont(Font.font("viner hand itc", 50));
		message.setTextFill(Color.WHITE);
		message.setAlignment(Pos.CENTER);
		message.setVisible(false);
		
		replay = new Button("REPLAY");
		replay.setId("Button");
		replay.setPrefSize(120, 60);
		replay.setLayoutX(10);
		replay.setLayoutY(40);
		replay.setFont(Font.font("viner hand itc", 21));
		replay.setOnAction(new EventHandler<ActionEvent>()
		{
			@Override
			public void handle(ActionEvent arg0)
			{
				exit.setDisable(true);
				exit.setVisible(false);
				message.setVisible(false);
				begin();
			}			
		});
		
		exit = new Button("EXIT");
		exit.setId("Button");
		exit.setPrefSize(120, 60);
		exit.setLayoutX(470);
		exit.setLayoutY(40);
		exit.setFont(Font.font("viner hand itc", 24));
		exit.setOnAction(new EventHandler<ActionEvent>()
		{
			@Override
			public void handle(ActionEvent arg0)
			{
				System.exit(0);
			}
			
		});
		
		root.getChildren().add(vboard);
		root.getChildren().add(name);
		root.getChildren().add(message);
		root.getChildren().add(replay);
		root.getChildren().add(exit);
		return;
	}
	
	private void begin()
	{
		board = new Hashtable<Integer, String>();
		
		for(int i=0;i<9;i++)
		{
			board.put(i, "");
		}
		
		for(Button b: cells)
		{
			b.setDisable(false);
			b.setText("");
			b.setPrefSize(100, 100);
			b.setFont(Font.font("viner hand itc", 33));
			b.setAlignment(Pos.CENTER);
			b.setTextFill(Color.MAROON);
			b.setOnAction(new TurnClick(b));
		}
	}
	
	private class TurnClick implements EventHandler<ActionEvent>
	{
		private Button button;

		public TurnClick(Button b)
		{
			this.button = b;
		}

		@Override
		public void handle(ActionEvent arg0)
		{
			if(board.get(Integer.parseInt(button.getId().substring(button.getId().length()-1))).compareTo("")==0)
			{
				turn(Integer.parseInt(button.getId().substring(button.getId().length()-1)), user);
				if(!gameTie())
				{
					turn(bestSpot(board, computer), computer);
				}
				else
				{
					exit.setDisable(false);
					exit.setVisible(true);
					message.setVisible(true);
					for(Button b: cells)
					{
						b.setDisable(true);
					}
				}
			}
		}
	}
	
	private ArrayList<Integer> emptyCells()
	{
		ArrayList<Integer> empty = new ArrayList<Integer>();
		
		for(Integer i: board.keySet())
		{
			if(board.get(i).compareTo("")==0)
			{
				empty.add(i);
			}
		}
		return empty;
	}
	
	public class Spot
	{
		int index;
		int score;
		
		public int getIndex()
		{
			return this.index;
		}
		
		public void setIndex(int i)
		{
			this.index = i;
		}
		
		public int getScore()
		{
			return this.score;
		}
		
		public void setScore(int s)
		{
			this.score = s;
		}
	}
	
	private int bestSpot(Hashtable<Integer, String> board, String player)
	{
		return miniMax(board, player).getIndex();
	}
	
	private Spot miniMax(Hashtable<Integer, String> board, String player)
	{
		ArrayList<Integer> empty = emptyCells();
		
		if(checkWon(board, user))
		{
			Spot temp = new Spot();
			temp.setScore(-1);
			return temp;
		}
		else if(checkWon(board, computer))
		{
			Spot temp = new Spot();
			temp.setScore(1);
			return temp;
		}
		else if(empty.size()==0)
		{
			Spot temp = new Spot();
			temp.setScore(0);
			return temp;
		}
		
		ArrayList<Spot> moves = new ArrayList<Spot>();
		
		for(Integer i: empty)
		{
			Spot move = new Spot();
			move.setIndex(i);
			board.replace(i, player);
			
			if(player.compareTo(user)==0)
			{
				Spot r = miniMax(board, computer);
				move.setScore(r.getScore());
			}
			else
			{
				Spot r = miniMax(board, user);
				move.setScore(r.getScore());
			}
			
			board.replace(i, "");
			
			moves.add(move);
		}
		
		Spot sweetSpot = new Spot();
		
		if(player.compareTo(computer)==0)
		{
			int s = Integer.MIN_VALUE;
			for(Spot spot: moves)
			{
				if(spot.getScore()>s)
				{
					s = spot.getScore();
					sweetSpot = spot;
				}
			}
		}
		else
		{
			int s = Integer.MAX_VALUE;
			for(Spot spot: moves)
			{
				if(spot.getScore()<s)
				{
					s = spot.getScore();
					sweetSpot = spot;
				}
			}
		}
		
		return sweetSpot;
	}
	
	private boolean gameTie()
	{
		if(emptyCells().size()==0)
		{
			return true;
		}
		return false;
	}
	
	private void turn(int id, String player)
	{
		board.replace(id, player);
		cells.get(id).setText(player);
		boolean gameWon = checkWon(board, player);
		if(gameWon)
		{
			exit.setDisable(false);
			exit.setVisible(true);
			message.setVisible(true);
			for(Button b: cells)
			{
				b.setDisable(true);
			}
		}
	}
	
	private boolean checkWon(Hashtable<Integer, String> board, String player)
	{
		ArrayList<Integer> pcells = new ArrayList<Integer>();

		for(Integer i: board.keySet())
		{
			if(board.get(i).compareTo(player)==0)
			{
				pcells.add(i);
			}
		}
		
		boolean won = false;
		
		for(ArrayList<Integer> a: wincombos)
		{
			if(pcells.contains(a.get(0)) && pcells.contains(a.get(1)) && pcells.contains(a.get(2)))
			{
				won = true;
			}
		}

		return won;
	}

	@Override
	public void start(Stage primaryStage)
	{
		stage = primaryStage;
		try
		{
			root = new AnchorPane();
			root.setPrefSize(600, 550);
			root.setId("Background");

			AudioClip clip = new AudioClip("file:src/Audio/Hopeful.mp3");
			clip.play();
			initialise();

			Scene scene = new Scene(root,600,550);
			stage.setTitle("Tic-Tac-Toe");
			stage.setResizable(false);
			stage.getIcons().add(new Image("/Images/icon.jpg"));
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			stage.setScene(scene);
			stage.show();
			
			begin();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public static void main(String[] args)
	{
		launch(args);
	}
}